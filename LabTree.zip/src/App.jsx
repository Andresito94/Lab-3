import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Counter from "./assets/Components/Counter";
import Toggle from "./assets/Components/Toggle";
import EmojiStore from './assets/Components/EmojiStore';
import Squidward from '../components/ColorBox';


function App() {
 
  return (
    <>
    <div>
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    </div>
    <div>
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    </div>
    <div>
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    </div>
    <div>
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    </div>
    <div>
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    <Squidward />
    </div>


    {/* <Counter />
    <Toggle />
    <EmojiStore /> */}
    </>
  )
}

export default App
